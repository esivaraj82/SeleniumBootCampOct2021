package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import Base.ProjectSpecificMethods;

public class LegalEntities extends ProjectSpecificMethods {

	//Click on New Legal Entity
	public LegalEntities clickNewLegalEntity() throws InterruptedException {
		driver.findElement(By.xpath("//div[text()='New']")).click();
		Thread.sleep(3000);
		return this;

	}
	//Enter Name as 'Salesforce Automation by Your Name'
	public LegalEntities enterNameLegalEntities() {
		driver.findElement(By.xpath("//input[@class=' input']")).sendKeys("Salesforce Automation by Sivaraj");
		return this;
	}

	//click Save
	public LegalEntities clickSaveLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(3000);
		return this;
	}

	//verify Legal Entity Name
	public LegalEntities verifyLegalEntityName() {
		String verifyText = driver.findElement(By.xpath("(//span[@class='uiOutputText'])[3]")).getText();
		System.out.println(verifyText);
		return this;
	}

	//Search the Legal Entity 'Salesforce Automation by Your Name'
	public LegalEntities searchLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys("Salesforce Automation by Sivaraj"+Keys.ENTER);
		Thread.sleep(3000);
		return this;
	}

	//Click on the Dropdown icon and Select Edit
	public LegalEntities clickEditLegalEntities() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		Thread.sleep(3000);
		return this;
	}

	//Enter the Company name as 'Testleaf'
	public LegalEntities editCompanyNameinLegalEntities() {
		driver.findElement(By.xpath("(//input[@class=' input'])[2]")).clear();
		driver.findElement(By.xpath("(//input[@class=' input'])[2]")).sendKeys("TestLeaf");
		return this;
	}

	//Enter Description as 'SalesForce'.
	public LegalEntities editDescriptioninLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).clear();
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).sendKeys("SalesForce");
		Thread.sleep(3000);
		return this;
	}

	//Select Status as 'Active'
	public LegalEntities editStatusinLegalEntities() {
		driver.findElement(By.xpath("//a[@class='select']")).click();
		driver.findElement(By.xpath("//a[text()='Active']")).click();
		return this;
	}

	//Click on Save and Verify Status as Active
	public LegalEntities editSaveinLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//a[contains(@class,'slds-truncate outputLookupLink')]")).click();
		Thread.sleep(3000);
		String status = driver.findElement(By.xpath("//span[text()='Active']")).getText();
		System.out.println(status);
		return this;
	}
}
