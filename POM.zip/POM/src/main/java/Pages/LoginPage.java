package Pages;

import org.openqa.selenium.By;

import Base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage enterUserName() {
		driver.findElement(By.id("username")).sendKeys("makaia@testleaf.com");
		return this;
	}

	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("SelBootcamp$1234");
		return this;
	}


	public HomePage clickLogIn() throws InterruptedException {
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		return new HomePage();
	}


}
