package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import Base.ProjectSpecificMethods;

public class WorkTypeGroup extends ProjectSpecificMethods{


	//Click on the Dropdown icon in the Work Type Groups tab
	public WorkTypeGroup clickWorkTypeGroupsTab() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("(//span[contains(text(),'Work Type Groups')])[3]")));
		Thread.sleep(5000);
		return this;
	}
	//Click on New Work Type Group
	public WorkTypeGroup clickNewWorkTypeGroup() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='New Work Type Group']")));
		Thread.sleep(3000);
		return this;
	}

	//Enter Work Type Group Name as 'Salesforce Automation by Your Name'
	public WorkTypeGroup enterWorkName() throws InterruptedException {
		driver.findElement(By.xpath("//input[@class=' input']")).sendKeys("Salesforce Automation by Sivaraj");
		Thread.sleep(5000);
		return this;
	}

	//click Save
	public WorkTypeGroup clicksave() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(5000);
		return this;
	}

	//verify Work Type Group Name
	public WorkTypeGroup verifyText() {
		String verifyText = driver.findElement(By.xpath("(//span[@class='uiOutputText'])[2]")).getText();
		System.out.println(verifyText);
		return this;
	}

	//Search the Work Type Group 'Salesforce Automation by Your Name'
	public WorkTypeGroup searchWorkTypeGroupText() throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys("Salesforce Automation by Sivaraj"+Keys.ENTER);
		Thread.sleep(4000);
		return this;
	}

	//Click on the Dropdown icon and Select Edit
	public WorkTypeGroup selectEditDropDown() throws InterruptedException {
		driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		Thread.sleep(3000);
		return this;
	}

	//Enter Description as 'Automation'.
	public WorkTypeGroup editDescription() throws InterruptedException {
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).clear();
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).sendKeys("Automation");
		return this;
	}


	//Select Group Type as 'Capacity'
	public WorkTypeGroup editCapacity() throws InterruptedException {
		driver.findElement(By.className("select")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@title='Capacity']")).click();
		return this;
	}

	//Click on Save
	public WorkTypeGroup editWorkTypeSave() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(4000);
		return this;
	}

	//Click on 'Salesforce Automation by Your Name'and Verify Description as 'Automation'
	public WorkTypeGroup verifyWorkTypeGroupText() throws InterruptedException {
		driver.findElement(By.xpath("(//a[@data-aura-class='forceOutputLookup'])[1]")).click();
		Thread.sleep(3000);
		String verifyDescription = driver.findElement(By.xpath("//span[@data-aura-class='uiOutputTextArea']")).getText();
		System.out.println(verifyDescription);
		return this;
	}
}
