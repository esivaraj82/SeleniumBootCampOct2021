package Pages;

import org.openqa.selenium.By;

import Base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

	public HomePage clickAppLauncher() {
		driver.findElement(By.className("slds-r5")).click();
		return this;
	}


	//Click view All
	public HomePage clickViewAll() {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		return this;
	}

	//click Sales from App Launcher
	public MyHomePage clickSales()  {
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
		return new MyHomePage();

	}

	//click Legal Entity from App Launcher
	public LegalEntities clickLegalEntities() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//p[text()='Legal Entities']")));
		Thread.sleep(5000);
		return new LegalEntities();

	}
	
	//click Service Console from App Launcher
		public DashBoard clickServiceConsole() throws InterruptedException {
			driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//p[text()='Service Console']")));
			Thread.sleep(5000);
			return new DashBoard();

		}
		
	//Click Work Type Group from App Launcher
		public WorkTypeGroup clickWorkTypeGroup() throws InterruptedException {
			driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//p[text()='Work Type Groups']")));
			Thread.sleep(5000);
			return new WorkTypeGroup();
		}
}
