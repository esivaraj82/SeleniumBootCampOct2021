package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.ProjectSpecificMethods;

public class DashBoard extends ProjectSpecificMethods{

	//Select Home from the DropDown
	public DashBoard clickHomefromDropDown() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Show Navigation Menu']")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Home']")));
		return this;
	}

	//Select Dashboards from DropDown
	public DashBoard clickDashBoardfromDropDown() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Show Navigation Menu']")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Dashboards']")));
		Thread.sleep(5000);
		return this;
	}

	//Click on New Dashboard
	public DashBoard clickNewDashboard() throws InterruptedException {
		driver.findElement(By.xpath("//div[text()='New Dashboard']")).click();
		Thread.sleep(5000);
		return this;
	}

	//Enter the Dashboard name as "YourName_Workout"
	public DashBoard enterNameinDashboard() throws InterruptedException {
		WebElement frame = driver.findElement(By.xpath("//iframe[@title='dashboard']"));
		driver.switchTo().frame(frame);
		driver.findElement(By.xpath("//input[@id='dashboardNameInput']")).sendKeys("Sivaraj");
		Thread.sleep(5000);
		return this;
	}
	//Enter Description as Testing and Click on Create
	public DashBoard enterDescriptioninDashboard() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='dashboardDescriptionInput']")).sendKeys("Testing");
		Thread.sleep(5000);
		driver.findElement(By.id("submitBtn")).click();
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		return this;
	}

	//Verify Title
	public DashBoard verifyTitle() throws InterruptedException {
		String browserTitle = driver.getTitle();
		System.out.println("Browser Title: "+browserTitle);
		Thread.sleep(5000);
		return this;
	}

	//Click on Done
	public DashBoard clickDone() throws InterruptedException {
		WebElement frame = driver.findElement(By.xpath("//iframe[@title='dashboard']"));
		driver.switchTo().frame(frame);
		driver.executeScript("arguments[0].click()",
				driver.findElement(By.xpath("//div[@class='toolbarActions']/button")));
		Thread.sleep(5000);
		return this;
	}

	//Verify the Dashboard is Created
	public DashBoard verifyDashboardName()  {
		String verifyDashboard = driver.findElement(By.xpath("//span[@class='slds-page-header__title slds-truncate']")).getText();
		System.out.println("Dashboard Name :"+verifyDashboard);
		return this;
	}
	//Click on Subscribe
	public DashBoard clickSubscribe() throws InterruptedException  {
		driver.findElement(By.xpath("//button[text()='Subscribe']")).click();
		Thread.sleep(5000);
		return this;
	}

	//Select Frequency as "Daily"
	public DashBoard clickDaily() throws InterruptedException  {
		driver.switchTo().defaultContent();
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='Daily']")));
		Thread.sleep(5000);
		return this;
	}

	//Time as 10:00 AM
	public DashBoard chooseTime() throws InterruptedException  {
		WebElement time = driver.findElement(By.xpath("//select[@class=' select']"));
		Select sel = new Select(time);
		sel.selectByVisibleText("10:00 AM");
		Thread.sleep(5000);
		return this;
	}

	//Click on Save
	public DashBoard clickSubscribeSave() throws InterruptedException  {
		driver.findElement(By.xpath("//span[text()='Save']")).click();
		Thread.sleep(5000);
		return this;
	}

	//Verify "You started Dashboard Subscription" message displayed or not
	@SuppressWarnings("deprecation")
	public DashBoard verifyDashboardSubscription() {
		WebElement name = driver.findElement(By.xpath("//div[@class='forceVisualMessageQueue']"));
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeSelected(name));
		return this;
	}

	//Close the "YourName_Workout" tab
	public DashBoard closeWorkOutTab() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='Actions for Sivaraj']")));
		Thread.sleep(4000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='Close Tab']")));
		Thread.sleep(5000);
		return this;
	}

	//Click on Private Dashboards
	public DashBoard clickPrivateDashBoards() throws InterruptedException {
		driver.findElement(By.xpath("//a[text()='Private Dashboards']")).click();
		Thread.sleep(5000);
		return this;
	}

	//Verify the newly created Dashboard available
	public DashBoard searchDashboardName() throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search private dashboards...']")).sendKeys("Sivaraj", Keys.ENTER);
		Thread.sleep(5000);
		return this;
	}

	//Click on dropdown for the item
	public DashBoard clickDropDownitem() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//button[@class='slds-button slds-button_icon-border slds-button_icon-x-small']")));
		Thread.sleep(5000);
		return this;
	}

	//Select Delete
	public DashBoard clickDelete() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Delete']")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='Close this window']")));
		return this;
	}

	//Confirm the Delete
	public DashBoard confirmDelete() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Delete']")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//button[@title='Delete']/span")));
		Thread.sleep(5000);
		return this;
	}


	//Verify the item is not available under Private Dashboard folder
	public DashBoard itemNotAvailable() throws InterruptedException {
		String item = driver.findElement(By.xpath("//span[@class='emptyMessageTitle']")).getText();
		System.out.println(item);
		return this;
	}

}
