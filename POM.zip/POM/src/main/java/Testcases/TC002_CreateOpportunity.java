package Testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC002_CreateOpportunity extends ProjectSpecificMethods{

	@BeforeTest
	public void setData() {
		excelFileName = "createOpportunity";
	}

	@Test(dataProvider="fetchData")
	public void createOpportunity(String name, String cdate) throws InterruptedException {
		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickSales()
		.clickOpportunity()
		.clickNewOpportunity()
		.enterOpportunityName(name)
		.enterCloseDate(cdate)
		.selectStage()
		.clickSave();
	}

}
