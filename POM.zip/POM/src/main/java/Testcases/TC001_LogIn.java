package Testcases;

import org.testng.annotations.Test;
import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC001_LogIn extends ProjectSpecificMethods{

	@Test
	public void runLogIn() throws InterruptedException {

		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn();
	}

}
