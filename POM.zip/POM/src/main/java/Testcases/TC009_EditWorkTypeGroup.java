package Testcases;

import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC009_EditWorkTypeGroup extends ProjectSpecificMethods {
	
	@Test
	public void createWorkTypeGroup() throws InterruptedException {
		
		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickWorkTypeGroup()
		.searchWorkTypeGroupText()
		.selectEditDropDown()
		.editDescription()
		.editCapacity()
		.editWorkTypeSave()
		.verifyWorkTypeGroupText();
	}

}
