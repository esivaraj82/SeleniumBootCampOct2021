package Testcases;

import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC004_DeleteOpportunity extends ProjectSpecificMethods {

	@Test
	public void deleteOpportunity() throws InterruptedException {

		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickSales()
		.clickOpportunity()
		.searchOpportunity()
		.clickDelete()
		.verifyText();

	}

}
